from django.apps import AppConfig


class ContractEmpAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Contract_Emp_App'
